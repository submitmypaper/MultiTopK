﻿#include <iostream>
#include <cmath>
#include "Tree.h"
#include "TStream.h"
int main()
{

    clock_t startTime, endTime;
    int pown[] = { 11,17,11,18,12,19,13,20,14,21,15,22,16,23,  13,20,13,20,13,20,13,20,13,20,13,20, 13,20,13,20,13,20,13,20,13,20,13,20,13,20 ,   13,20,13,20,13,20,13,20,13,20 ,  13,21,13,21,13,21,13,21,13,23,13,24 };
    int k_range[] = { 100,50,100,50,100,50,100,50,100,50,100,50,100,50,  10,7,50,20,100,50,200,100,500,200,1000,500, 100,50,100,50,100,50,100,50,100,50,100,50,100,50 ,  100,50,100,50,100,50,100,50,100,50    ,100,10,100,20,100,50,100,100,100,200,100,300 };
    int query[] = { 100,100,100,100,100,100,100,100,100,100,100,100,100,100,   100,100,100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,100,100,100,100,  10,10,100,100,200,200,500,500,1000,1000   ,100,100,100,100,100,100,100,100,100,100,100,100 };
    float s[] = { 100,50,100,50,100,50,100,50,100,50,100,50,100,50,
                 100,50,100,50,100,50,100,50,100,50,100,50,
                 10000,5000,2000,1000,1000,500,200,100,100,50,20,10,10,5,
                 100,50,100,50,100,50,100,50,100,50 ,
                 100,10,100,20,100,30,100,40,100,50,100,50,100,50 };
    float dev[] = { 1,1,1,1,1,1,1,  1,1,1,1,1,1,  1,1,1,1,1,1,1,  1,1,1,1,1,  0.1,0.2,0.5,1,2,3 };
    int wl,j=0;
    for (int i = 0; i < sizeof(pown); ) 
    {
        TStream tstream;
        Tree tree;
        TStream::QParameter q;
        tstream.SetQueryTimes(1000);
        q.k.first = k_range[i];
        wl = query[i];
        q.slide.first = s[i];
        q.n.first = pown[i++];
        q.k.second = k_range[i];
        q.slide.second = s[i];
        q.n.second = pown[i++];
        tstream.RandomNormalWorkLoad(wl, q, dev[j]);
        tstream.ReadDataFile();
        cout << "parmeter    Window range: " << q.n.first << "-" << q.n.second << "    k range: " << q.k.first << "-" << q.k.second << "  work load: " << wl << "  SD: " << dev[j++] << endl;
        tree.initEnodeVec(tstream);
        tree.initEnode(tstream);
        tree.initTreeNode();
        startTime = clock();
        tree.updateDataFlow(tstream);
        endTime = clock();
        cout << "  Running Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
        cout << "Process " << 52428800 / ((double)(endTime - startTime) / CLOCKS_PER_SEC) << " data per second " << endl;
    }
}

